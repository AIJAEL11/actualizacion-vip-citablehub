export const dynamic = 'force-dynamic';

export async function GET() {
  const content = `# CitableHub
> CitableHub is a free structured profile platform that helps businesses and software projects become discoverable and citable by AI search engines like ChatGPT, Perplexity, and Google AI.
 
## What we do
We provide AI-readable profiles with a Citability Score across 5 dimensions: Identity, Evidence, Trust, Freshness, and Classification. Every profile is free. No subscriptions.
 
## Business model
Free to list. Users pay only for GQI Boost — a paid visibility promotion that pushes their profile to more users and AI systems (sold in hours, days, or weeks).
 
## Our data
- 589+ structured business and software profiles
- JSON-LD schema (SoftwareApplication, Organization) on every profile page
- Public API at /api/projects
- Updated daily as new profiles are added
 
## Key pages
- https://citablehub.com — Homepage
- https://citablehub.com/projects — Full directory
- https://citablehub.com/p/[slug] — Individual profile pages
 
## Contact
team@citablehub.com
 
## Parent company
Wildverse LLC — wildverse.io`;

  return new Response(content, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'public, max-age=86400, s-maxage=86400',
    },
  });
}
