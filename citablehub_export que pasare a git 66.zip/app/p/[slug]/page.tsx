export const dynamic = "force-dynamic";

import { prisma } from '@/lib/db';
import { ProjectProfileClient } from '@/components/project-profile-client';
import { notFound } from 'next/navigation';
import { Metadata } from 'next';
import { headers } from 'next/headers';

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const headersList = headers();
  const host = headersList.get('x-forwarded-host') || 'citablehub.com';
  const protocol = headersList.get('x-forwarded-proto') || 'https';
  const siteUrl = `${protocol}://${host}`;

  let project: any = null;
  try {
    project = await prisma.project.findFirst({ where: { slug: params?.slug } });
  } catch {}

  if (!project) {
    return { title: 'Project Not Found — CitableHub' };
  }

  const title = `${project.name} — CitableHub Verified Profile`;
  const description = project.summary || project.description || `${project.name} on CitableHub. Verified software with citable evidence.`;
  const url = `${siteUrl}/p/${project.slug}`;

  return {
    title,
    description,
    alternates: {
      canonical: url,
    },
    openGraph: {
      title,
      description,
      url,
      siteName: 'CitableHub',
      type: 'article',
      images: [{ url: `${siteUrl}/logo.png`, width: 512, height: 512, alt: project.name }],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [`${siteUrl}/logo.png`],
    },
  };
}

export default async function ProjectProfilePage({ params }: { params: { slug: string } }) {
  let project: any = null;
  try {
    project = await prisma.project.findFirst({
      where: { slug: params?.slug },
      include: { evidences: true, projectUpdates: true },
    }) as any;
  } catch (e) {
    console.warn('Failed to load project:', e);
  }

  if (!project) {
    notFound();
  }

  // Increment impressions
  try {
    await prisma.project.update({
      where: { id: project.id },
      data: { impressions: { increment: 1 } },
    });
  } catch {}

  const serialized = {
    ...(project ?? {}),
    createdAt: project?.createdAt?.toISOString?.() ?? '',
    updatedAt: project?.updatedAt?.toISOString?.() ?? '',
    launchDate: (project as any)?.launchDate?.toISOString?.() ?? null,
    lastReviewed: (project as any)?.lastReviewed?.toISOString?.() ?? null,
    evidences: (project?.evidences ?? []).map((e: any) => ({
      ...(e ?? {}),
      createdAt: e?.createdAt?.toISOString?.() ?? '',
    })),
    projectUpdates: (project?.projectUpdates ?? []).map((u: any) => ({
      ...(u ?? {}),
      createdAt: u?.createdAt?.toISOString?.() ?? '',
    })),
  };

  return <ProjectProfileClient project={serialized} />;
}
