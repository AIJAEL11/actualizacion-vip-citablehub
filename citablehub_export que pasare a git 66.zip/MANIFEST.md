# CitableHub — Complete Platform Manifest

> **For AI agents reviewing this codebase**: This document is the single source of truth for understanding, debugging, and enhancing CitableHub. Read it completely before making any changes.

## 🎯 What CitableHub Is

CitableHub is a **free AI-visibility platform** that helps digital products (SaaS, apps, tools) get discovered and cited by AI search engines (ChatGPT, Perplexity, Claude, Gemini, Google AI Overview).

It does this by creating **structured, machine-readable profiles** for each listed project — with JSON-LD schema, citability scoring, and promotion tools.

**It is NOT** a traditional directory. It's an **entity resolution platform for AI systems**.

## 💰 Business Model

- **100% free to list** — no subscriptions, no credit card required
- Revenue comes ONLY from **one-time GQI Boost purchases** (paid visibility campaigns)
- Three boost tiers:
  - **Starter**: $100 → 2,000 GQI, 24h duration
  - **Launch**: $250 → 6,000 GQI, 7 days
  - **Growth**: $500 → 15,000 GQI, 30 days
- Stripe is in **LIVE mode** with real payment keys

## 🏗️ Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Database**: PostgreSQL via Prisma ORM
- **Auth**: NextAuth.js (credentials + Google OAuth)
- **Payments**: Stripe (live mode)
- **Styling**: Tailwind CSS + shadcn/ui components
- **Animations**: Framer Motion
- **File Storage**: AWS S3 (presigned URLs)
- **LLM Provider**: Abacus AI (OpenAI-compatible API)
- **Analytics**: Google Analytics 4 (GA4)
- **Deployment**: Hosted on Abacus AI platform
- **Domain**: citablehub.com (Cloudflare CDN)

## 📁 Project Structure

```
nextjs_space/
├── app/
│   ├── api/                    # All API routes
│   │   ├── admin/              # Admin stats, ranking recalculation, intelligence
│   │   ├── analytics/track/    # Event tracking (bot/human classification)
│   │   ├── auth/               # NextAuth + login + signup
│   │   ├── categories/         # Category listing
│   │   ├── contact/            # Contact form (sends email)
│   │   ├── health/             # Health check endpoint
│   │   ├── intents/            # Intent tags
│   │   ├── llm/chat/           # Discovery AI chat (streaming)
│   │   ├── llm/scan/           # AI autofill for project submissions
│   │   ├── notifications/      # User notification CRUD
│   │   ├── out/                # Click-out tracking (redirect)
│   │   ├── projects/           # Project CRUD + claim + save
│   │   ├── stripe/             # Checkout, portal, webhook, session
│   │   ├── upload/presigned/   # S3 presigned URL generation
│   │   └── user/profile/       # User profile management
│   ├── auth/signin/            # Sign-in page
│   ├── checkout/success/       # Post-payment success page
│   ├── llms.txt/               # LLM discovery file (plain text)
│   ├── p/[slug]/               # Individual project profile (SSR)
│   ├── projects/               # SSR paginated directory
│   ├── robots.ts               # Dynamic robots.txt (AI bot rules)
│   ├── rss.xml/                # Dynamic RSS feed
│   ├── sitemap.ts              # Dynamic sitemap
│   ├── layout.tsx              # Root layout
│   ├── page.tsx                # Homepage (SPA shell)
│   └── globals.css             # Global styles
├── components/
│   ├── views/                  # SPA view components
│   │   ├── landing-view.tsx    # Homepage content (hero, features, carousel, FAQ)
│   │   ├── chat-view.tsx       # Discovery AI chat interface
│   │   ├── discover-view.tsx   # Filterable project browser
│   │   ├── submit-view.tsx     # Project submission form
│   │   ├── dashboard-view.tsx  # User dashboard (edit projects, KPIs)
│   │   ├── boost-view.tsx      # GQI Boost purchase flow
│   │   ├── promotion-view.tsx  # Personalized promotion checklist
│   │   ├── admin-view.tsx      # Admin panel (stats, ranking)
│   │   ├── settings-view.tsx   # User settings
│   │   ├── privacy-view.tsx    # Privacy policy
│   │   ├── terms-view.tsx      # Terms of service
│   │   └── contact-view.tsx    # Contact form
│   ├── citablehub-app.tsx      # Main SPA shell (routing, nav, footer)
│   ├── project-profile-client.tsx  # Project detail page (client)
│   ├── projects-directory-client.tsx # Directory list (client)
│   ├── floating-sidebar.tsx    # Top Projects sidebar
│   ├── signin-client.tsx       # Auth forms
│   ├── google-analytics.tsx    # GA4 integration
│   └── providers.tsx           # SessionProvider + ThemeProvider
├── lib/
│   ├── auth-options.ts         # NextAuth config
│   ├── aws-config.ts           # S3 client setup
│   ├── citability-scores.ts    # 5-dimension scoring (Identity, Evidence, Trust, Freshness, Classification)
│   ├── completeness.ts         # Profile completeness calculator (0-1)
│   ├── copy-generator.ts       # Pre-written promotion copy generator
│   ├── db.ts                   # Prisma client singleton
│   ├── destinations.ts         # Promotion destinations database
│   ├── dynamic-ranking.ts      # Signal-weighted ranking engine
│   ├── faq-data.ts             # FAQ items (11 questions, used in JSON-LD + UI)
│   ├── indexnow.ts             # IndexNow instant URL submission
│   ├── llm-broker.ts           # LLM API with failover
│   ├── notifications.ts        # In-app + email notification system
│   ├── ranking.ts              # Tier-based ranking (partner > boost > real > seeded)
│   ├── s3.ts                   # S3 upload helpers
│   ├── stripe.ts               # Stripe config + boost packages
│   ├── types.ts                # TypeScript interfaces
│   └── utils.ts                # Shared utilities (cn, etc.)
├── prisma/
│   └── schema.prisma           # Database schema (see below)
├── scripts/
│   └── seed.ts                 # Database seeder (589 demo projects)
├── public/
│   ├── logos/                  # Ecosystem logos (9 PNGs)
│   ├── logo.png                # CitableHub logo
│   └── 619a8a...txt            # IndexNow verification file
├── middleware.ts               # SPA route rewrites
├── tailwind.config.ts          # Theme config (animations, colors)
└── .env                        # Environment variables
```

## 🗄️ Database Schema (PostgreSQL + Prisma)

### Core Models

| Model | Purpose | Row Count |
|---|---|---|
| User | Auth accounts (credentials + Google OAuth) | ~15 |
| Project | Listed products/tools with AI-citable profiles | 599 (589 seeded + 10 real) |
| Evidence | Supporting proof links for projects | varies |
| BoostOrder | GQI Boost purchases (Stripe) | few |
| Category | Project categories (developer-tools, ai-ml, etc.) | ~18 |
| IntentTag | Intent classification tags | ~12 |
| AnalyticsEvent | Click/view/save tracking with bot classification | growing |
| Notification | In-app + email notifications | varies |
| ClaimRequest | Project ownership claims | few |
| AuditLog | Admin audit trail | varies |
| ChatSession | Discovery AI chat history | varies |
| TrustSignal | Schema validation results | varies |
| ProjectUpdate | Project changelog entries | varies |

### Key Project Fields

- `isSeeded: Boolean` — true for demo data (lower ranking priority)
- `platformPartner: Boolean` — pinned to top of rankings (currently: CitableHub, Wildverse)
- `dynamicScore: Float` — calculated from human-weighted analytics signals
- `trustScore / boostScore / aiReadinessScore: Float` — scoring dimensions
- `status`: invited | registered | verified | rejected | flagged | draft
- `claimable: Boolean` — whether the project can be claimed by its owner
- `slug: String @unique` — URL-friendly identifier for /p/[slug]

### Important Schema Notes

- `summary` is REQUIRED (not nullable)
- The URL field is `url`, NOT `website`
- Category field is `category`, NOT `mainCategory`
- `socialLinks` is stored as JSON (e.g., `{"twitter": "...", "github": "..."}`)
- DB is SHARED between dev and production — be careful with mutations

## 🔐 Authentication

- **Admin email**: rafaelzoom83@gmail.com (auto-assigned admin role)
- **Providers**: Credentials (email/password) + Google OAuth
- **Session**: JWT-based via NextAuth
- **Protected routes**: All `/api/` routes that modify data require session
- **Admin routes**: `/api/admin/*` require `role === 'admin'`

## 📊 Ranking System (4 Tiers)

Defined in `lib/ranking.ts`:

1. **Platform Partners** (`platformPartner: true`) — always at top
2. **Active Boost** (`boostScore > 0`) — paid visibility
3. **Real projects** (`isSeeded: false`) — sorted by dynamicScore
4. **Seeded projects** (`isSeeded: true`) — demo data, lowest priority

Within each tier: `dynamicScore` desc → legacy formula → newest first.

### Dynamic Scoring (`lib/dynamic-ranking.ts`)

Weighted signals from AnalyticsEvent:
- `project_click`: 3 pts
- `project_save`: 5 pts
- `project_click_website`: 4 pts
- `project_view`: 1 pt
- `project_impression`: 0.5 pts
- Bot signals count at 10% weight
- Completeness bonus: up to 5 pts
- Active boost bonus: 10 pts flat

### Citability Score (`lib/citability-scores.ts`)

5 dimensions, each 0-100:
1. **Identity** — name, URL, logo, summary, founder, social links
2. **Evidence** — outcome statement, evidence links, demo URL, description depth
3. **Trust** — contact info, support URL, privacy/terms, verification status
4. **Freshness** — version, launch date, last reviewed, recent updates
5. **Classification** — category, tags, use cases, audience tags, platform type

Overall = weighted average of all 5.

## 🤖 AI/GEO Infrastructure

### Already Implemented

1. **JSON-LD on every page**:
   - Homepage: Organization + WebApplication + WebSite + FAQPage (11 items) + SearchAction
   - Profile pages: BreadcrumbList + SoftwareApplication + WebPage
   - No fake reviews or ratings — all data is real

2. **`/llms.txt`** — plain text LLM discovery file describing the platform

3. **`/rss.xml`** — dynamic RSS feed with 20 most recent profiles

4. **`/robots.txt`** — explicit Allow rules for:
   GPTBot, Google-Extended, PerplexityBot, ClaudeBot, anthropic-ai, GoogleOther, Bytespider, CCBot

5. **`/sitemap.xml`** — dynamic sitemap with all project profiles

6. **IndexNow** — instant URL submission to Bing/Yandex on project create/edit/claim
   - Key: `619a8a3ee4c6478ea1395f1e976ed286a2355fe4`
   - Verification file at `/619a8a3ee4c6478ea1395f1e976ed286a2355fe4.txt`
   - Hooks in: POST /api/projects, PATCH /api/projects/[id], POST /api/projects/claim

7. **Bot classification** in analytics tracking (`lib/` + `/api/analytics/track`)

### NOT Yet Implemented (Opportunities)

- `/.well-known/ai-plugin.json` — AI plugin discovery file
- `/about` page — SSR-rendered rich text page for crawlers
- Embeddable "Citable Verified" badge for listed projects
- Auto-generated comparison pages (`/compare/tool-a-vs-tool-b`)
- Auto-generated category landing pages (`/best/ai-productivity-tools`)
- Open Graph images per project profile

## 💳 Stripe Integration (LIVE)

- **Mode**: LIVE (real money)
- **Products**: One-time GQI Boost checkout sessions
- **Webhook**: `/api/stripe/webhook` handles `checkout.session.completed`
- **Portal**: `/api/stripe/portal` for customer management
- **Keys**: In `.env` (STRIPE_SECRET_KEY, NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY, STRIPE_WEBHOOK_SECRET)

## 📧 Email Notifications

System uses Abacus AI notification API. Registered notification types:
- Profile Completeness Reminder
- Ranking Movement Alert
- Citability Score Update
- Boost Benefits Info
- Weekly Performance Digest
- Contact Form Submission

Triggered automatically on project create/edit when completeness < 80%.

## 🎨 SPA Architecture

The app uses a **hybrid SPA + SSR** approach:

- **SPA routes** (handled by `middleware.ts` → rewritten to `/`):
  `/chat`, `/discover`, `/boost`, `/dashboard`, `/dashboard/promotion`, `/submit`, `/settings`, `/admin`, `/privacy`, `/terms`, `/contact`

- **SSR routes** (separate Next.js pages):
  `/`, `/projects`, `/p/[slug]`, `/auth/signin`, `/checkout/success`

- **API routes**: All under `/api/`

The SPA shell (`citablehub-app.tsx`) reads `_spa_path` from URL params and renders the appropriate view.

## 🔑 Environment Variables

| Variable | Purpose |
|---|---|
| DATABASE_URL | PostgreSQL connection string |
| NEXTAUTH_SECRET | JWT signing secret |
| NEXTAUTH_URL | Auto-set by platform |
| ABACUSAI_API_KEY | LLM API access |
| STRIPE_SECRET_KEY | Stripe server key (LIVE) |
| NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY | Stripe client key (LIVE) |
| STRIPE_WEBHOOK_SECRET | Stripe webhook signature |
| GOOGLE_CLIENT_ID | Google OAuth |
| GOOGLE_CLIENT_SECRET | Google OAuth |
| AWS_S3_BUCKET_NAME | File upload bucket |
| AWS_S3_REGION | S3 region |
| AWS_ACCESS_KEY_ID | S3 access |
| AWS_SECRET_ACCESS_KEY | S3 secret |
| NEXT_PUBLIC_GA4_MEASUREMENT_ID | Google Analytics |
| INDEXNOW_KEY | IndexNow API key |
| NOTIF_ID_* | Email notification type IDs (6 types) |
| NOTIFICATION_EMAIL_API_KEY | Abacus notification API |
| NOTIFICATION_EMAIL_API_URL | Notification endpoint |

## ⚠️ Known Issues & Quirks

1. **Cloudflare 403 for some AI fetchers**: Claude's real-time web search gets blocked by Cloudflare (infrastructure level, not our code). All bot user-agents return 200 when tested directly.

2. **SPA routes return 200 with SPA shell**: `/privacy`, `/contact`, `/terms` are SPA routes — crawlers that don't execute JavaScript won't see the content. Consider making these SSR pages.

3. **589 seeded projects have LLM-generated data**: Enriched via `gpt-5.4-mini`. Some may have imperfect descriptions. All are flagged with `isSeeded: true`.

4. **External links in seeded profiles may be dead**: Some URLs point to non-existent sites (e.g., mindsparks.app, cognoplan.ai). These are part of the seed data.

5. **Logo carousel duplicates are intentional**: The infinite scroll carousel doubles the logo array for seamless animation.

6. **`pricing-view.tsx` still exists** but is unreachable — removed from nav/routing. Can be safely deleted.

## 🚀 What Claude Code Should Focus On

### HIGH PRIORITY — AI Discoverability
1. Make `/privacy`, `/terms`, `/contact`, and potentially `/about` into **proper SSR pages** so crawlers can read them without JavaScript
2. Add `/.well-known/ai-plugin.json` for AI discovery
3. Create **programmatic content pages** (comparisons, category pages) that are SSR-rendered and provide unique value to AI crawlers
4. Add response headers (`X-Robots-Tag: all`) to signal openness to crawlers

### MEDIUM PRIORITY — Platform Value
5. Embeddable "Citable Verified" badge (generates backlinks when owners embed it)
6. Better meta tags / Open Graph images per project
7. Make the public scan (citability check) work without login as a viral acquisition tool

### LOW PRIORITY — Polish
8. Remove dead `pricing-view.tsx`
9. Clean up any TypeScript warnings
10. Improve mobile responsiveness where needed

### DO NOT TOUCH
- Stripe keys or webhook logic (live payments)
- Database schema (shared with production — any migration risks data loss)
- Auth configuration (working with real users)
- IndexNow key or verification file
- Seed script (already ran, 589 projects exist)
- The `isSeeded` / `platformPartner` flags on existing records

## 👤 Owner Info

- **Owner**: Rafael
- **Admin email**: rafaelzoom83@gmail.com
- **Company**: Wildverse LLC (wildverse.io)
- **Platform Partners**: CitableHub (self), Wildverse
- **Domain**: citablehub.com

---

*Last updated: June 13, 2026*
*Generated by Abacus AI Agent for Claude Code handoff*
