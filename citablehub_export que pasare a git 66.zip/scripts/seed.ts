import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

function generateCHVerId(id: string): string {
  const hash = id.replace(/[^a-zA-Z0-9]/g, '');
  const num = parseInt(hash.slice(-6), 36) || 0;
  return `CH-VER-${String(num % 1000000).padStart(6, '0')}`;
}

async function main() {
  console.log('Seeding CitableHub database...');

  // Seed admin user
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash('johndoe123', salt);

  const adminUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      name: 'John Doe',
      displayName: 'John Doe',
      passwordHash: hash,
      role: 'admin',
      subscription: 'pro',
    },
  });
  console.log('Admin user created:', adminUser.id);

  // Categories (expanded)
  const categories = [
    { id: 'developer-tools', name: 'Developer Tools', description: 'SDKs, APIs, deployment utilities, and monitoring boards.' },
    { id: 'finance', name: 'Finance & Fintech', description: 'Ledgers, accounting hubs, payment APIs, and crypto tools.' },
    { id: 'productivity', name: 'Productivity & AI', description: 'Cognitive assistants, task suites, and workflow automation.' },
    { id: 'marketing-sales', name: 'Marketing & Sales', description: 'Lead discovery, customer intelligence, copy optimization.' },
    { id: 'design-creative', name: 'Design & Creative', description: 'UI design tools, image editors, video production platforms.' },
    { id: 'education', name: 'Education & Learning', description: 'E-learning platforms, course builders, tutoring systems.' },
    { id: 'healthcare', name: 'Healthcare & Wellness', description: 'Telemedicine, health tracking, clinical tools.' },
    { id: 'ecommerce', name: 'E-Commerce & Retail', description: 'Storefronts, inventory management, shipping solutions.' },
    { id: 'security', name: 'Security & Compliance', description: 'Cybersecurity tools, identity management, compliance automation.' },
    { id: 'data-analytics', name: 'Data & Analytics', description: 'BI dashboards, data pipelines, visualization tools.' },
    { id: 'communication', name: 'Communication & Collaboration', description: 'Messaging, video conferencing, team workspaces.' },
    { id: 'infrastructure', name: 'Infrastructure & DevOps', description: 'Cloud hosting, CI/CD, containerization, monitoring.' },
  ];

  for (const cat of categories) {
    await prisma.category.upsert({
      where: { id: cat.id },
      update: { name: cat.name, description: cat.description },
      create: { ...cat, count: 0 },
    });
  }
  console.log('Categories seeded:', categories.length);

  // Intent Tags (expanded)
  const intentTags = [
    { id: 'build', name: 'Build', description: 'Tools to build products and features.' },
    { id: 'automate', name: 'Automate', description: 'Automate repetitive tasks and workflows.' },
    { id: 'analyze', name: 'Analyze', description: 'Analyze data, metrics, and insights.' },
    { id: 'secure', name: 'Secure', description: 'Protect data, systems, and users.' },
    { id: 'collaborate', name: 'Collaborate', description: 'Work together with teams.' },
    { id: 'learn', name: 'Learn', description: 'Education and skill development.' },
    { id: 'design', name: 'Design', description: 'Create visual assets and interfaces.' },
    { id: 'sell', name: 'Sell', description: 'Sell products and services online.' },
    { id: 'communicate', name: 'Communicate', description: 'Messaging and notifications.' },
    { id: 'optimize', name: 'Optimize', description: 'Improve performance and reduce costs.' },
  ];

  for (const tag of intentTags) {
    await prisma.intentTag.upsert({
      where: { id: tag.id },
      update: { name: tag.name, description: tag.description },
      create: { ...tag, count: 0 },
    });
  }
  console.log('Intent tags seeded:', intentTags.length);

  // ============================================================
  // 100 REAL-WORLD PROJECTS — status: "invited", claimable: true
  // These represent real tools/apps discovered via business cards,
  // conferences, and industry research. No owner assigned yet.
  // ============================================================

  const invitedProjects = [
    // --- Developer Tools (15) ---
    { name: 'Postman', slug: 'postman', url: 'https://postman.com', category: 'developer-tools', summary: 'API platform for building and using APIs', description: 'Postman is an API platform for building and using APIs. Postman simplifies each step of the API lifecycle and streamlines collaboration so you can create better APIs—faster.', tags: ['api', 'testing', 'rest', 'graphql'], trustScore: 0.85 },
    { name: 'Vercel', slug: 'vercel', url: 'https://vercel.com', category: 'developer-tools', summary: 'Frontend cloud platform for deploying web applications', description: 'Vercel provides the developer tools and cloud infrastructure to build, scale, and secure a faster, more personalized web. Deploy instantly with zero configuration.', tags: ['deployment', 'frontend', 'serverless', 'edge'], trustScore: 0.90 },
    { name: 'Supabase', slug: 'supabase', url: 'https://supabase.com', category: 'developer-tools', summary: 'Open source Firebase alternative with PostgreSQL', description: 'Supabase is an open source Firebase alternative. Start your project with a Postgres database, Authentication, instant APIs, Edge Functions, Realtime subscriptions, Storage, and Vector embeddings.', tags: ['database', 'auth', 'realtime', 'backend'], trustScore: 0.82 },
    { name: 'Railway', slug: 'railway', url: 'https://railway.app', category: 'developer-tools', summary: 'Infrastructure platform for deploying apps effortlessly', description: 'Railway is an infrastructure platform where you can provision infrastructure, develop with that infrastructure locally, and then deploy to the cloud. No Dockerfiles, no configs—just code.', tags: ['deployment', 'infrastructure', 'cloud', 'devops'], trustScore: 0.75 },
    { name: 'PlanetScale', slug: 'planetscale', url: 'https://planetscale.com', category: 'developer-tools', summary: 'Serverless MySQL platform with branching workflows', description: 'PlanetScale is a MySQL-compatible serverless database platform. It features database branching, non-blocking schema changes, and unlimited scaling for modern applications.', tags: ['database', 'mysql', 'serverless', 'scaling'], trustScore: 0.78 },
    { name: 'Render', slug: 'render', url: 'https://render.com', category: 'developer-tools', summary: 'Unified cloud to build and run all your apps', description: 'Render is a unified cloud to build and run all your apps and websites with free TLS certificates, a global CDN, DDoS protection, private networks, and auto deploys from Git.', tags: ['cloud', 'hosting', 'deployment', 'web-services'], trustScore: 0.72 },
    { name: 'Neon', slug: 'neon', url: 'https://neon.tech', category: 'developer-tools', summary: 'Serverless Postgres with branching and auto-scaling', description: 'Neon is a fully managed serverless PostgreSQL. It separates storage and compute to offer features like database branching, bottomless storage, and scale to zero.', tags: ['postgres', 'serverless', 'database', 'branching'], trustScore: 0.76 },
    { name: 'Resend', slug: 'resend', url: 'https://resend.com', category: 'developer-tools', summary: 'Email API for developers built on modern infrastructure', description: 'Resend is the email API for developers. Build, test, and deliver transactional emails at scale with a modern developer experience and beautiful email templates.', tags: ['email', 'api', 'transactional', 'developer'], trustScore: 0.70 },
    { name: 'Upstash', slug: 'upstash', url: 'https://upstash.com', category: 'developer-tools', summary: 'Serverless data platform for Redis and Kafka', description: 'Upstash provides serverless Redis and Kafka for developers. Pay-per-request pricing, durable storage, and global replication for edge and serverless applications.', tags: ['redis', 'kafka', 'serverless', 'caching'], trustScore: 0.73 },
    { name: 'Convex', slug: 'convex', url: 'https://convex.dev', category: 'developer-tools', summary: 'Reactive backend platform for full-stack development', description: 'Convex is a full-stack TypeScript development platform. It replaces your database, server functions, and glue code with a single, elegant backend solution.', tags: ['backend', 'typescript', 'realtime', 'fullstack'], trustScore: 0.68 },
    { name: 'Axiom', slug: 'axiom', url: 'https://axiom.co', category: 'developer-tools', summary: 'Log management and observability for modern applications', description: 'Axiom enables organizations to monitor, debug, and understand their data. Ingest and query unlimited data with zero configuration for comprehensive log management.', tags: ['logging', 'observability', 'monitoring', 'debugging'], trustScore: 0.71 },
    { name: 'Trigger.dev', slug: 'trigger-dev', url: 'https://trigger.dev', category: 'developer-tools', summary: 'Open source background jobs framework for TypeScript', description: 'Trigger.dev is the open source background jobs framework for TypeScript. Create reliable workflows with retries, scheduling, and real-time monitoring.', tags: ['background-jobs', 'typescript', 'workflow', 'scheduling'], trustScore: 0.65 },
    { name: 'Inngest', slug: 'inngest', url: 'https://inngest.com', category: 'developer-tools', summary: 'Durable workflow engine for modern applications', description: 'Inngest is the durable workflow engine that lets you build reliable applications without queues or infrastructure. Write functions, deploy anywhere, run reliably.', tags: ['workflow', 'serverless', 'events', 'durable'], trustScore: 0.67 },
    { name: 'Mintlify', slug: 'mintlify', url: 'https://mintlify.com', category: 'developer-tools', summary: 'Beautiful documentation that converts users', description: 'Mintlify is a modern documentation platform that helps teams create beautiful, user-friendly docs that actually convert visitors into users.', tags: ['documentation', 'docs', 'api-docs', 'developer-experience'], trustScore: 0.72 },
    { name: 'Warp', slug: 'warp', url: 'https://warp.dev', category: 'developer-tools', summary: 'AI-powered terminal for modern developers', description: 'Warp is a modern, Rust-based terminal with AI built in. Features include intelligent autocomplete, collaborative workflows, and a beautiful, fast interface.', tags: ['terminal', 'ai', 'cli', 'developer-experience'], trustScore: 0.74 },

    // --- Productivity & AI (15) ---
    { name: 'Notion', slug: 'notion', url: 'https://notion.so', category: 'productivity', summary: 'All-in-one workspace for notes, tasks, wikis, and databases', description: 'Notion is the connected workspace where better, faster work happens. Get docs, projects, and knowledge all in one place for teams of every size.', tags: ['workspace', 'notes', 'project-management', 'wiki'], trustScore: 0.92 },
    { name: 'Linear', slug: 'linear', url: 'https://linear.app', category: 'productivity', summary: 'Streamlined project and issue tracking for software teams', description: 'Linear is a purpose-built tool for modern product development. Streamline issues, projects, and product roadmaps with a fast and elegant experience.', tags: ['issue-tracking', 'project-management', 'agile', 'engineering'], trustScore: 0.88 },
    { name: 'Raycast', slug: 'raycast', url: 'https://raycast.com', category: 'productivity', summary: 'Supercharged productivity launcher for macOS', description: 'Raycast is a blazingly fast, totally extendable launcher. It lets you complete tasks, calculate, share common links, and much more right from your desktop.', tags: ['launcher', 'macos', 'productivity', 'extensions'], trustScore: 0.80 },
    { name: 'Obsidian', slug: 'obsidian', url: 'https://obsidian.md', category: 'productivity', summary: 'Private knowledge base with linked thinking', description: 'Obsidian is a powerful knowledge base on top of a local folder of plain text Markdown files. Build a personal wiki with bidirectional linking and graph visualization.', tags: ['notes', 'markdown', 'knowledge-base', 'personal'], trustScore: 0.83 },
    { name: 'Cron', slug: 'cron-calendar', url: 'https://cron.com', category: 'productivity', summary: 'Next-generation calendar for professionals', description: 'Cron is the next-generation calendar for professionals and teams. Features include availability sharing, scheduling links, and a beautiful interface.', tags: ['calendar', 'scheduling', 'time-management', 'teams'], trustScore: 0.70 },
    { name: 'Loom', slug: 'loom', url: 'https://loom.com', category: 'productivity', summary: 'Async video messaging for work communication', description: 'Loom is a video messaging tool that helps you get your message across through instantly shareable videos. Record screen, camera, or both for async communication.', tags: ['video', 'async', 'communication', 'screen-recording'], trustScore: 0.82 },
    { name: 'Otter.ai', slug: 'otter-ai', url: 'https://otter.ai', category: 'productivity', summary: 'AI meeting assistant for transcription and notes', description: 'Otter.ai uses AI to generate real-time transcriptions, meeting notes, and summaries. Automatically join and transcribe your meetings.', tags: ['transcription', 'ai', 'meetings', 'notes'], trustScore: 0.75 },
    { name: 'Granola', slug: 'granola', url: 'https://granola.ai', category: 'productivity', summary: 'AI notepad for meetings with automatic enhancement', description: 'Granola is an AI notepad that sits quietly during meetings and enhances your notes with context from the conversation, creating comprehensive meeting documentation.', tags: ['notes', 'meetings', 'ai', 'documentation'], trustScore: 0.62 },
    { name: 'Tldraw', slug: 'tldraw', url: 'https://tldraw.com', category: 'productivity', summary: 'Collaborative infinite canvas whiteboard', description: 'Tldraw is a collaborative digital whiteboard with an infinite canvas. Draw, diagram, and design together with real-time collaboration.', tags: ['whiteboard', 'drawing', 'collaboration', 'canvas'], trustScore: 0.68 },
    { name: 'Cal.com', slug: 'cal-com', url: 'https://cal.com', category: 'productivity', summary: 'Open source scheduling infrastructure', description: 'Cal.com is the open source Calendly alternative. Build on top of scheduling infrastructure that powers millions of bookings worldwide.', tags: ['scheduling', 'open-source', 'bookings', 'calendar'], trustScore: 0.77 },
    { name: 'Perplexity', slug: 'perplexity', url: 'https://perplexity.ai', category: 'productivity', summary: 'AI-powered answer engine with real-time research', description: 'Perplexity is an AI-powered answer engine that provides accurate, trusted, and real-time answers to any question with cited sources.', tags: ['ai', 'search', 'research', 'answers'], trustScore: 0.86 },
    { name: 'Mem.ai', slug: 'mem-ai', url: 'https://mem.ai', category: 'productivity', summary: 'AI-powered workspace that organizes itself', description: 'Mem is the self-organizing workspace. Use AI to automatically organize your notes, find related information, and surface insights when you need them.', tags: ['notes', 'ai', 'knowledge-management', 'organization'], trustScore: 0.63 },
    { name: 'Taskade', slug: 'taskade', url: 'https://taskade.com', category: 'productivity', summary: 'AI-powered productivity platform for teams', description: 'Taskade is an AI-powered productivity platform that unifies tasks, notes, mind maps, and video chat for teams. Build AI agents to automate your workflows.', tags: ['tasks', 'ai', 'collaboration', 'mind-maps'], trustScore: 0.66 },
    { name: 'Superhuman', slug: 'superhuman', url: 'https://superhuman.com', category: 'productivity', summary: 'Fastest email experience ever made', description: 'Superhuman is the fastest email experience ever made. It provides blazingly fast email with AI-powered features like instant reply, scheduled messages, and read statuses.', tags: ['email', 'productivity', 'ai', 'communication'], trustScore: 0.79 },
    { name: 'Coda', slug: 'coda', url: 'https://coda.io', category: 'productivity', summary: 'All-in-one doc that brings together documents and apps', description: 'Coda is a doc that grows with your idea. Start with a blank page and build docs as powerful as apps, with building blocks like tables, buttons, and automations.', tags: ['documents', 'no-code', 'automation', 'collaboration'], trustScore: 0.76 },

    // --- Finance & Fintech (10) ---
    { name: 'Mercury', slug: 'mercury', url: 'https://mercury.com', category: 'finance', summary: 'Banking stack for startups and scaling companies', description: 'Mercury is the financial technology company building banking for startups. Features include checking/savings accounts, corporate cards, treasury management, and venture debt.', tags: ['banking', 'startups', 'fintech', 'treasury'], trustScore: 0.84 },
    { name: 'Ramp', slug: 'ramp', url: 'https://ramp.com', category: 'finance', summary: 'Corporate card and spend management platform', description: 'Ramp is the corporate card and spend management platform designed to help businesses save time and money. Automate expense reports, control spending, and close books faster.', tags: ['expense', 'corporate-card', 'spend-management', 'accounting'], trustScore: 0.81 },
    { name: 'Brex', slug: 'brex', url: 'https://brex.com', category: 'finance', summary: 'AI-powered spend platform for modern companies', description: 'Brex is the AI-powered spend platform that automates finance workflows. Corporate cards, expense management, travel, and bill pay in one unified platform.', tags: ['corporate-card', 'ai', 'expense', 'travel'], trustScore: 0.80 },
    { name: 'Plaid', slug: 'plaid', url: 'https://plaid.com', category: 'finance', summary: 'Financial infrastructure connecting apps to bank accounts', description: 'Plaid powers fintech and digital finance products. Connect your app to users bank accounts for payments, identity verification, and financial data.', tags: ['api', 'banking', 'payments', 'financial-data'], trustScore: 0.88 },
    { name: 'Stripe', slug: 'stripe', url: 'https://stripe.com', category: 'finance', summary: 'Payment infrastructure for the internet', description: 'Stripe is a technology company that builds economic infrastructure for the internet. Millions of companies use Stripe to accept payments, send payouts, and manage their businesses online.', tags: ['payments', 'api', 'subscriptions', 'commerce'], trustScore: 0.95 },
    { name: 'Wise', slug: 'wise', url: 'https://wise.com', category: 'finance', summary: 'International money transfers with low fees', description: 'Wise (formerly TransferWise) provides international money transfers at the real exchange rate. Send and receive money across borders with transparent, low fees.', tags: ['transfers', 'international', 'exchange-rate', 'remittance'], trustScore: 0.87 },
    { name: 'Deel', slug: 'deel', url: 'https://deel.com', category: 'finance', summary: 'Global payroll and compliance for remote teams', description: 'Deel is the all-in-one HR platform for global teams. It handles payroll, compliance, HR, and IT for employees and contractors in 150+ countries.', tags: ['payroll', 'compliance', 'hr', 'global'], trustScore: 0.83 },
    { name: 'Lemon Squeezy', slug: 'lemon-squeezy', url: 'https://lemonsqueezy.com', category: 'finance', summary: 'All-in-one platform for selling digital products', description: 'Lemon Squeezy handles payments, tax, subscriptions, and more, so you can focus on building and selling your digital products worldwide.', tags: ['payments', 'digital-products', 'subscriptions', 'saas'], trustScore: 0.71 },
    { name: 'Paddle', slug: 'paddle', url: 'https://paddle.com', category: 'finance', summary: 'Complete payments and tax compliance for SaaS', description: 'Paddle is the complete payments, tax, and subscription management platform for SaaS companies. One integration handles payments, billing, and global tax compliance.', tags: ['payments', 'saas', 'tax', 'billing'], trustScore: 0.76 },
    { name: 'Moov', slug: 'moov', url: 'https://moov.io', category: 'finance', summary: 'Open source financial infrastructure for building payment products', description: 'Moov is an open source financial technology company building cloud-native financial infrastructure. Embed payments, transfers, and financial services into your application.', tags: ['payments', 'open-source', 'fintech', 'infrastructure'], trustScore: 0.64 },

    // --- Design & Creative (10) ---
    { name: 'Figma', slug: 'figma', url: 'https://figma.com', category: 'design-creative', summary: 'Collaborative interface design tool for teams', description: 'Figma is a collaborative web application for interface design. It features real-time collaboration, prototyping, design systems, and developer handoff tools.', tags: ['ui-design', 'prototyping', 'collaboration', 'design-systems'], trustScore: 0.94 },
    { name: 'Framer', slug: 'framer', url: 'https://framer.com', category: 'design-creative', summary: 'Design and publish stunning websites with no code', description: 'Framer is a web design tool that lets you design and publish stunning sites. Start with AI, create with visual design tools, and publish your portfolio, startup, or side project.', tags: ['web-design', 'no-code', 'websites', 'animation'], trustScore: 0.81 },
    { name: 'Spline', slug: 'spline', url: 'https://spline.design', category: 'design-creative', summary: '3D design tool for the web with real-time collaboration', description: 'Spline is a free 3D design tool for the web. Create interactive 3D web experiences, product mockups, and visual content with real-time collaboration.', tags: ['3d-design', 'web', 'interactive', 'collaboration'], trustScore: 0.70 },
    { name: 'Rive', slug: 'rive', url: 'https://rive.app', category: 'design-creative', summary: 'Interactive animations for products and games', description: 'Rive is a real-time interactive design tool that allows designers and developers to create and ship interactive animations for products, apps, sites, and games.', tags: ['animation', 'interactive', 'design', 'motion'], trustScore: 0.72 },
    { name: 'Midjourney', slug: 'midjourney', url: 'https://midjourney.com', category: 'design-creative', summary: 'AI-powered image generation for creative professionals', description: 'Midjourney is an independent research lab exploring new mediums of thought and expanding the imaginative powers of the human species through AI image generation.', tags: ['ai', 'image-generation', 'creative', 'art'], trustScore: 0.85 },
    { name: 'Canva', slug: 'canva', url: 'https://canva.com', category: 'design-creative', summary: 'Visual communication platform for design creation', description: 'Canva empowers everyone in the world to design anything and publish anywhere. Create presentations, social media graphics, videos, and more with thousands of templates.', tags: ['design', 'templates', 'social-media', 'presentations'], trustScore: 0.91 },
    { name: 'Lottie', slug: 'lottiefiles', url: 'https://lottiefiles.com', category: 'design-creative', summary: 'Lightweight animations for web and mobile apps', description: 'LottieFiles lets you create, edit, test, and share Lottie animations. The easiest way to add lightweight, scalable animations to your websites and apps.', tags: ['animation', 'lottie', 'motion-design', 'web'], trustScore: 0.73 },
    { name: 'Penpot', slug: 'penpot', url: 'https://penpot.app', category: 'design-creative', summary: 'Open source design and prototyping platform', description: 'Penpot is the first open source design tool for design and code collaboration. Design, prototype, and deliver with full creative freedom.', tags: ['design', 'open-source', 'prototyping', 'collaboration'], trustScore: 0.69 },
    { name: 'Pitch', slug: 'pitch', url: 'https://pitch.com', category: 'design-creative', summary: 'Collaborative presentation software for modern teams', description: 'Pitch is collaborative presentation software designed for modern teams. Create beautiful presentations, collaborate in real-time, and share across your organization.', tags: ['presentations', 'collaboration', 'design', 'teams'], trustScore: 0.71 },
    { name: 'PhotoRoom', slug: 'photoroom', url: 'https://photoroom.com', category: 'design-creative', summary: 'AI-powered photo editing for product and marketing images', description: 'PhotoRoom removes backgrounds and creates product images using AI. Perfect for e-commerce sellers, marketers, and content creators who need professional visuals.', tags: ['photo-editing', 'ai', 'background-removal', 'ecommerce'], trustScore: 0.74 },

    // --- Marketing & Sales (10) ---
    { name: 'HubSpot', slug: 'hubspot', url: 'https://hubspot.com', category: 'marketing-sales', summary: 'CRM platform for marketing, sales, and customer service', description: 'HubSpot is a CRM platform with all the software, integrations, and resources you need to connect marketing, sales, content management, and customer service.', tags: ['crm', 'marketing', 'sales', 'inbound'], trustScore: 0.90 },
    { name: 'Lemlist', slug: 'lemlist', url: 'https://lemlist.com', category: 'marketing-sales', summary: 'Cold email outreach and sales engagement platform', description: 'Lemlist helps sales teams personalize cold emails at scale, automate follow-ups, and book more meetings with prospects through multi-channel outreach.', tags: ['cold-email', 'outreach', 'sales', 'personalization'], trustScore: 0.72 },
    { name: 'Apollo.io', slug: 'apollo-io', url: 'https://apollo.io', category: 'marketing-sales', summary: 'Sales intelligence and engagement platform', description: 'Apollo is an all-in-one sales intelligence platform with tools to prospect, engage, and drive more revenue. Access a database of 275M+ contacts and 73M+ companies.', tags: ['sales', 'prospecting', 'b2b', 'data'], trustScore: 0.79 },
    { name: 'Jasper', slug: 'jasper', url: 'https://jasper.ai', category: 'marketing-sales', summary: 'AI copilot for enterprise marketing teams', description: 'Jasper is the AI copilot for better marketing outcomes. Generate on-brand content, analyze campaigns, and accelerate your marketing with enterprise-grade AI.', tags: ['ai', 'content', 'marketing', 'copywriting'], trustScore: 0.77 },
    { name: 'Beehiiv', slug: 'beehiiv', url: 'https://beehiiv.com', category: 'marketing-sales', summary: 'Newsletter platform built for growth', description: 'Beehiiv is the newsletter platform built for growth. Create, grow, and monetize your newsletter with powerful tools used by the worlds top publications.', tags: ['newsletter', 'email', 'growth', 'monetization'], trustScore: 0.74 },
    { name: 'Dub', slug: 'dub', url: 'https://dub.co', category: 'marketing-sales', summary: 'Open source link management infrastructure', description: 'Dub.co is the open source link management infrastructure for modern marketing teams. Short links, QR codes, analytics, and branded links all in one platform.', tags: ['links', 'analytics', 'marketing', 'open-source'], trustScore: 0.67 },
    { name: 'PostHog', slug: 'posthog', url: 'https://posthog.com', category: 'marketing-sales', summary: 'Open source product analytics suite', description: 'PostHog is the open source product analytics suite. Product analytics, session recording, feature flags, A/B testing, and more—all in one platform you can self-host.', tags: ['analytics', 'product', 'open-source', 'feature-flags'], trustScore: 0.82 },
    { name: 'Customer.io', slug: 'customer-io', url: 'https://customer.io', category: 'marketing-sales', summary: 'Automated messaging platform for tech-savvy marketers', description: 'Customer.io is a versatile automated messaging platform for tech-savvy marketers who want more control and flexibility to send data-driven communications.', tags: ['messaging', 'automation', 'marketing', 'engagement'], trustScore: 0.75 },
    { name: 'Typeform', slug: 'typeform', url: 'https://typeform.com', category: 'marketing-sales', summary: 'Beautiful forms and surveys that people enjoy filling out', description: 'Typeform makes collecting information comfortable and conversational. Create beautiful forms, surveys, quizzes, and more with a focus on user experience.', tags: ['forms', 'surveys', 'lead-generation', 'ux'], trustScore: 0.80 },
    { name: 'Clearbit', slug: 'clearbit', url: 'https://clearbit.com', category: 'marketing-sales', summary: 'B2B data enrichment and intelligence platform', description: 'Clearbit is a data enrichment tool that helps businesses understand their customers, identify future prospects, and personalize every interaction across the customer journey.', tags: ['data-enrichment', 'b2b', 'intelligence', 'leads'], trustScore: 0.78 },

    // --- Education & Learning (8) ---
    { name: 'Coursera', slug: 'coursera', url: 'https://coursera.org', category: 'education', summary: 'Online learning platform with university courses', description: 'Coursera partners with universities and organizations to offer online courses, degrees, and certificates in data science, business, computer science, and more.', tags: ['courses', 'university', 'certificates', 'online-learning'], trustScore: 0.89 },
    { name: 'Teachable', slug: 'teachable', url: 'https://teachable.com', category: 'education', summary: 'Platform to create and sell online courses', description: 'Teachable is a platform that empowers creators to build and sell online courses, coaching, and memberships. No coding required to create your own digital education business.', tags: ['course-creation', 'coaching', 'monetization', 'creator'], trustScore: 0.76 },
    { name: 'Brilliant', slug: 'brilliant', url: 'https://brilliant.org', category: 'education', summary: 'Interactive STEM learning through problem solving', description: 'Brilliant is a platform for interactive learning in math, science, and computer science. Master concepts by solving fun, challenging problems and interactive lessons.', tags: ['stem', 'math', 'science', 'interactive'], trustScore: 0.82 },
    { name: 'Duolingo', slug: 'duolingo', url: 'https://duolingo.com', category: 'education', summary: 'Free language learning app with gamified lessons', description: 'Duolingo is the worlds most popular way to learn a language. Its 100% free, fun, and scientifically proven to work with bite-sized lessons and gamification.', tags: ['languages', 'gamification', 'mobile', 'free'], trustScore: 0.91 },
    { name: 'Replit', slug: 'replit', url: 'https://replit.com', category: 'education', summary: 'Browser-based IDE for building and learning to code', description: 'Replit is a browser-based IDE and development platform. Build, share, and deploy apps right from your browser with collaborative coding and AI assistance.', tags: ['ide', 'coding', 'collaboration', 'ai'], trustScore: 0.80 },
    { name: 'Codecademy', slug: 'codecademy', url: 'https://codecademy.com', category: 'education', summary: 'Interactive platform to learn programming skills', description: 'Codecademy is the easiest way to learn to code. Interactive, hands-on courses in Python, JavaScript, SQL, and more with real-world projects.', tags: ['coding', 'interactive', 'courses', 'programming'], trustScore: 0.83 },
    { name: 'Khan Academy', slug: 'khan-academy', url: 'https://khanacademy.org', category: 'education', summary: 'Free world-class education for anyone, anywhere', description: 'Khan Academy offers practice exercises, instructional videos, and a personalized learning dashboard across math, science, arts, computing, and more—all for free.', tags: ['free', 'k12', 'math', 'science'], trustScore: 0.93 },
    { name: 'Udemy', slug: 'udemy', url: 'https://udemy.com', category: 'education', summary: 'Online learning marketplace with expert-led courses', description: 'Udemy is an online learning marketplace with over 200,000 courses. Learn programming, design, marketing, and more from expert instructors worldwide.', tags: ['marketplace', 'courses', 'professional', 'skills'], trustScore: 0.85 },

    // --- E-Commerce & Retail (8) ---
    { name: 'Shopify', slug: 'shopify', url: 'https://shopify.com', category: 'ecommerce', summary: 'Commerce platform for building online stores', description: 'Shopify is a complete commerce platform that lets you start, grow, and manage a business. Build an online store, sell across channels, and manage everything from a single dashboard.', tags: ['ecommerce', 'stores', 'commerce', 'retail'], trustScore: 0.93 },
    { name: 'Gumroad', slug: 'gumroad', url: 'https://gumroad.com', category: 'ecommerce', summary: 'Platform to sell digital products directly to your audience', description: 'Gumroad helps creators sell products directly to their audience. Sell digital products, memberships, and courses with simple, creator-friendly tools.', tags: ['digital-products', 'creator', 'payments', 'marketplace'], trustScore: 0.78 },
    { name: 'BigCommerce', slug: 'bigcommerce', url: 'https://bigcommerce.com', category: 'ecommerce', summary: 'Enterprise e-commerce platform for scaling businesses', description: 'BigCommerce is a leading e-commerce platform for fast-growing and established brands. Build, innovate, and grow your online business with enterprise-grade tools.', tags: ['ecommerce', 'enterprise', 'b2b', 'omnichannel'], trustScore: 0.80 },
    { name: 'Medusa', slug: 'medusa', url: 'https://medusajs.com', category: 'ecommerce', summary: 'Open source composable commerce engine', description: 'Medusa is a set of commerce modules and tools that allow you to build rich, reliable, and performant commerce applications without reinventing core commerce logic.', tags: ['open-source', 'headless', 'commerce', 'composable'], trustScore: 0.69 },
    { name: 'Saleor', slug: 'saleor', url: 'https://saleor.io', category: 'ecommerce', summary: 'GraphQL-first open source e-commerce platform', description: 'Saleor is a GraphQL-first, headless e-commerce platform delivering personalized shopping experiences. API-driven, cloud-native, and developer-friendly.', tags: ['graphql', 'headless', 'open-source', 'api'], trustScore: 0.66 },
    { name: 'Printful', slug: 'printful', url: 'https://printful.com', category: 'ecommerce', summary: 'Print-on-demand and dropshipping fulfillment', description: 'Printful is an on-demand printing and fulfillment company. Create and sell custom products with no inventory, no risk, and automated order fulfillment.', tags: ['print-on-demand', 'dropshipping', 'fulfillment', 'custom'], trustScore: 0.77 },
    { name: 'Snipcart', slug: 'snipcart', url: 'https://snipcart.com', category: 'ecommerce', summary: 'Shopping cart platform for developers', description: 'Snipcart is a powerful shopping cart platform for developers. Add a shopping cart to any website in minutes with simple HTML and JavaScript integration.', tags: ['cart', 'developer', 'headless', 'integration'], trustScore: 0.65 },
    { name: 'WooCommerce', slug: 'woocommerce', url: 'https://woocommerce.com', category: 'ecommerce', summary: 'Open source e-commerce for WordPress', description: 'WooCommerce is the open source e-commerce platform built on WordPress. Sell anything, anywhere with the flexibility of WordPress and powerful commerce features.', tags: ['wordpress', 'open-source', 'ecommerce', 'plugins'], trustScore: 0.86 },

    // --- Security & Compliance (7) ---
    { name: 'Auth0', slug: 'auth0', url: 'https://auth0.com', category: 'security', summary: 'Identity platform for application authentication', description: 'Auth0 provides authentication and authorization as a service. Implement secure login for any application with universal login, SSO, MFA, and social login providers.', tags: ['auth', 'identity', 'sso', 'mfa'], trustScore: 0.87 },
    { name: 'Clerk', slug: 'clerk', url: 'https://clerk.com', category: 'security', summary: 'Complete user management and authentication platform', description: 'Clerk is a complete suite of embeddable UIs, flexible APIs, and admin dashboards to authenticate and manage users. Built for modern web applications.', tags: ['auth', 'user-management', 'react', 'embeddable'], trustScore: 0.80 },
    { name: 'Snyk', slug: 'snyk', url: 'https://snyk.io', category: 'security', summary: 'Developer-first security for code and dependencies', description: 'Snyk helps developers find and fix vulnerabilities in open source dependencies, container images, and infrastructure as code. Security built for developers.', tags: ['security', 'vulnerabilities', 'open-source', 'devsecops'], trustScore: 0.83 },
    { name: 'Vanta', slug: 'vanta', url: 'https://vanta.com', category: 'security', summary: 'Automated security and compliance platform', description: 'Vanta automates security and compliance for growing companies. Achieve SOC 2, ISO 27001, HIPAA, and other compliance certifications with continuous monitoring.', tags: ['compliance', 'soc2', 'iso27001', 'automated'], trustScore: 0.81 },
    { name: '1Password', slug: '1password', url: 'https://1password.com', category: 'security', summary: 'Password manager and digital vault for teams', description: '1Password is the easiest way to store and use strong passwords. A password manager that keeps all of your accounts safe with one master password.', tags: ['passwords', 'vault', 'teams', 'secrets'], trustScore: 0.90 },
    { name: 'Doppler', slug: 'doppler', url: 'https://doppler.com', category: 'security', summary: 'Universal secrets management platform', description: 'Doppler is the universal secrets manager. Centralize and manage environment variables and secrets across your team, projects, and infrastructure.', tags: ['secrets', 'env-vars', 'infrastructure', 'devops'], trustScore: 0.74 },
    { name: 'WorkOS', slug: 'workos', url: 'https://workos.com', category: 'security', summary: 'Enterprise-ready authentication and user management', description: 'WorkOS provides a modern identity platform for B2B SaaS. Enterprise SSO, SCIM provisioning, and multi-factor authentication in minutes, not months.', tags: ['enterprise', 'sso', 'scim', 'b2b'], trustScore: 0.76 },

    // --- Data & Analytics (7) ---
    { name: 'Mixpanel', slug: 'mixpanel', url: 'https://mixpanel.com', category: 'data-analytics', summary: 'Product analytics for building better products', description: 'Mixpanel is the most powerful product analytics tool. Track user behavior, measure feature adoption, and build better products with data-driven decisions.', tags: ['analytics', 'product', 'user-behavior', 'metrics'], trustScore: 0.84 },
    { name: 'Amplitude', slug: 'amplitude', url: 'https://amplitude.com', category: 'data-analytics', summary: 'Digital analytics platform for product intelligence', description: 'Amplitude is the digital analytics platform that helps teams understand user behavior, ship the right features, and grow their business with product intelligence.', tags: ['analytics', 'product', 'intelligence', 'growth'], trustScore: 0.82 },
    { name: 'Metabase', slug: 'metabase', url: 'https://metabase.com', category: 'data-analytics', summary: 'Open source business intelligence and analytics', description: 'Metabase is the easy, open source way for everyone in your company to ask questions and learn from data. Connect to your database and start exploring in minutes.', tags: ['bi', 'open-source', 'dashboards', 'sql'], trustScore: 0.80 },
    { name: 'Airbyte', slug: 'airbyte', url: 'https://airbyte.com', category: 'data-analytics', summary: 'Open source data integration platform', description: 'Airbyte is the open source data integration engine that helps you consolidate your data in your data warehouses, lakes, and databases.', tags: ['etl', 'data-integration', 'open-source', 'connectors'], trustScore: 0.74 },
    { name: 'Fivetran', slug: 'fivetran', url: 'https://fivetran.com', category: 'data-analytics', summary: 'Automated data movement platform', description: 'Fivetran delivers ready-to-use connectors that automatically adapt as schemas and APIs change, ensuring consistent, reliable data for analytics.', tags: ['etl', 'data-pipeline', 'connectors', 'warehouse'], trustScore: 0.81 },
    { name: 'dbt', slug: 'dbt', url: 'https://getdbt.com', category: 'data-analytics', summary: 'SQL-first transformation workflow for analytics engineering', description: 'dbt (data build tool) enables analytics engineers to transform data in their warehouses more effectively. Write modular SQL, test, and document your data transformations.', tags: ['sql', 'transformation', 'analytics', 'data-modeling'], trustScore: 0.85 },
    { name: 'Hex', slug: 'hex', url: 'https://hex.tech', category: 'data-analytics', summary: 'Collaborative analytics workspace for data teams', description: 'Hex is the collaborative data workspace where teams can work together on SQL, Python, and no-code analytics. Build analyses, reports, and data apps.', tags: ['notebooks', 'sql', 'python', 'collaboration'], trustScore: 0.72 },

    // --- Communication & Collaboration (8) ---
    { name: 'Slack', slug: 'slack', url: 'https://slack.com', category: 'communication', summary: 'Business messaging platform for teams', description: 'Slack is a messaging app for businesses that connects people to the information they need. By bringing people together to work as one unified team, Slack transforms organizational communication.', tags: ['messaging', 'teams', 'channels', 'integrations'], trustScore: 0.93 },
    { name: 'Discord', slug: 'discord', url: 'https://discord.com', category: 'communication', summary: 'Community platform for group communication', description: 'Discord is the easiest way to talk over voice, video, and text. Whether youre part of a school club, gaming group, worldwide art community, or just friends.', tags: ['community', 'voice', 'video', 'gaming'], trustScore: 0.89 },
    { name: 'Liveblocks', slug: 'liveblocks', url: 'https://liveblocks.io', category: 'communication', summary: 'Real-time collaboration infrastructure for developers', description: 'Liveblocks provides the building blocks for adding collaborative features to your product. Comments, notifications, text editing, and real-time APIs.', tags: ['realtime', 'collaboration', 'multiplayer', 'api'], trustScore: 0.68 },
    { name: 'Intercom', slug: 'intercom', url: 'https://intercom.com', category: 'communication', summary: 'AI-first customer service platform', description: 'Intercom is the AI-first customer service platform. Resolve customer issues faster with AI-powered chatbots, help centers, and proactive messaging.', tags: ['customer-service', 'ai', 'chat', 'support'], trustScore: 0.86 },
    { name: 'Crisp', slug: 'crisp', url: 'https://crisp.chat', category: 'communication', summary: 'Business messaging platform for startups and SMBs', description: 'Crisp is the all-in-one business messaging platform for startups. Live chat, CRM, knowledge base, and marketing automation in one simple tool.', tags: ['live-chat', 'crm', 'messaging', 'support'], trustScore: 0.70 },
    { name: 'Sendbird', slug: 'sendbird', url: 'https://sendbird.com', category: 'communication', summary: 'In-app chat and messaging API for mobile and web', description: 'Sendbird provides chat, voice, and video APIs for mobile apps and websites. Build real-time communication experiences with powerful SDKs and UI kits.', tags: ['chat-api', 'messaging', 'sdk', 'realtime'], trustScore: 0.75 },
    { name: 'Whereby', slug: 'whereby', url: 'https://whereby.com', category: 'communication', summary: 'Video meetings and telehealth with no downloads', description: 'Whereby provides easy video meetings with no app downloads. Embed video calling directly into your website or app with simple APIs and pre-built components.', tags: ['video-meetings', 'embed', 'telehealth', 'no-download'], trustScore: 0.72 },
    { name: 'Tally', slug: 'tally', url: 'https://tally.so', category: 'communication', summary: 'Simplest way to create beautiful forms for free', description: 'Tally is the simplest way to create forms. Build any type of form in seconds without knowing how to code, and for free. No limits on submissions or form complexity.', tags: ['forms', 'free', 'no-code', 'surveys'], trustScore: 0.73 },

    // --- Infrastructure & DevOps (7) ---
    { name: 'Cloudflare', slug: 'cloudflare', url: 'https://cloudflare.com', category: 'infrastructure', summary: 'Web performance and security cloud platform', description: 'Cloudflare provides a global network designed to make everything you connect to the Internet secure, private, fast, and reliable. CDN, DNS, DDoS protection, and more.', tags: ['cdn', 'security', 'dns', 'performance'], trustScore: 0.92 },
    { name: 'Fly.io', slug: 'fly-io', url: 'https://fly.io', category: 'infrastructure', summary: 'Deploy app servers close to your users globally', description: 'Fly.io transforms containers into micro-VMs that run on hardware in 35+ regions. Deploy your full-stack apps close to your users worldwide.', tags: ['deployment', 'edge', 'containers', 'global'], trustScore: 0.76 },
    { name: 'Coolify', slug: 'coolify', url: 'https://coolify.io', category: 'infrastructure', summary: 'Open source self-hosting platform alternative to Heroku', description: 'Coolify is an open-source, self-hostable alternative to Heroku, Netlify, and Vercel. Deploy databases, services, and applications with just a few clicks.', tags: ['self-hosting', 'open-source', 'paas', 'deployment'], trustScore: 0.65 },
    { name: 'Grafana', slug: 'grafana', url: 'https://grafana.com', category: 'infrastructure', summary: 'Open source analytics and monitoring platform', description: 'Grafana is the open source analytics & monitoring solution for every database. Create, explore, and share dashboards with beautiful visualizations.', tags: ['monitoring', 'dashboards', 'observability', 'open-source'], trustScore: 0.88 },
    { name: 'Sentry', slug: 'sentry', url: 'https://sentry.io', category: 'infrastructure', summary: 'Application monitoring and error tracking platform', description: 'Sentry provides self-hosted and cloud-based application performance monitoring & error tracking that helps all software teams discover, triage, and prioritize errors in real-time.', tags: ['error-tracking', 'monitoring', 'performance', 'debugging'], trustScore: 0.86 },
    { name: 'PagerDuty', slug: 'pagerduty', url: 'https://pagerduty.com', category: 'infrastructure', summary: 'Digital operations management for incident response', description: 'PagerDuty is the digital operations management platform that prevents and resolves business-impacting incidents. On-call management, alerting, and incident response.', tags: ['incident-response', 'on-call', 'alerting', 'operations'], trustScore: 0.84 },
    { name: 'Terraform', slug: 'terraform-cloud', url: 'https://app.terraform.io', category: 'infrastructure', summary: 'Infrastructure as code for cloud provisioning', description: 'Terraform Cloud is HashiCorps managed service for infrastructure as code. Provision and manage cloud infrastructure with declarative configuration files.', tags: ['iac', 'cloud', 'provisioning', 'devops'], trustScore: 0.87 },

    // --- Healthcare & Wellness (5) ---
    { name: 'Headspace', slug: 'headspace', url: 'https://headspace.com', category: 'healthcare', summary: 'Meditation and mindfulness app for everyday wellness', description: 'Headspace is your guide to mindfulness for your everyday life. Learn meditation and mindfulness to help you manage stress, sleep better, and be more present.', tags: ['meditation', 'mindfulness', 'wellness', 'mental-health'], trustScore: 0.85 },
    { name: 'Calm', slug: 'calm', url: 'https://calm.com', category: 'healthcare', summary: 'Sleep, meditation, and relaxation app', description: 'Calm is the #1 app for mental fitness. Experience lower stress, less anxiety, and more restful sleep with guided meditations, sleep stories, and relaxing music.', tags: ['sleep', 'meditation', 'anxiety', 'wellness'], trustScore: 0.84 },
    { name: 'Zocdoc', slug: 'zocdoc', url: 'https://zocdoc.com', category: 'healthcare', summary: 'Find and book doctors near you online', description: 'Zocdoc helps you find and book top-rated doctors, dentists, and specialists near you. Check insurance, read reviews, and book instantly—all for free.', tags: ['doctor', 'booking', 'insurance', 'healthcare'], trustScore: 0.81 },
    { name: 'Oura', slug: 'oura', url: 'https://ouraring.com', category: 'healthcare', summary: 'Smart ring for health and sleep tracking', description: 'Oura Ring is a smart ring that tracks sleep, activity, and readiness. Get personalized health insights delivered daily from the most accurate wearable.', tags: ['wearable', 'sleep', 'health-tracking', 'ring'], trustScore: 0.79 },
    { name: 'Noom', slug: 'noom', url: 'https://noom.com', category: 'healthcare', summary: 'Psychology-based approach to healthy weight management', description: 'Noom is a weight management program that uses psychology-based approaches to help you build healthier habits, lose weight, and keep it off long-term.', tags: ['weight-loss', 'psychology', 'habits', 'health'], trustScore: 0.75 },
  ];

  console.log(`Seeding ${invitedProjects.length} invited projects...`);

  for (const proj of invitedProjects) {
    await prisma.project.upsert({
      where: { slug: proj.slug },
      update: {
        name: proj.name,
        url: proj.url,
        summary: proj.summary,
        description: proj.description,
        category: proj.category,
        tags: proj.tags,
        trustScore: proj.trustScore,
      },
      create: {
        name: proj.name,
        slug: proj.slug,
        url: proj.url,
        email: '',
        summary: proj.summary,
        description: proj.description,
        outcome: '',
        targetAudience: '',
        category: proj.category,
        tags: proj.tags,
        status: 'invited',
        claimable: true,
        isSeeded: true,
        chVerId: generateCHVerId(proj.slug + 'seed'),
        trustScore: proj.trustScore,
        aiReadinessScore: Math.round((proj.trustScore * 0.8 + Math.random() * 0.2) * 100) / 100,
      },
    });
  }

  console.log('Invited projects seeded!');

  // Update category counts
  for (const cat of categories) {
    const count = await prisma.project.count({ where: { category: cat.id } });
    await prisma.category.update({ where: { id: cat.id }, data: { count } });
  }
  console.log('Category counts updated.');

  // Update intent tag counts
  for (const tag of intentTags) {
    const count = await prisma.project.count({ where: { tags: { has: tag.id } } });
    await prisma.intentTag.update({ where: { id: tag.id }, data: { count } });
  }
  console.log('Intent tag counts updated.');

  console.log('Seeding complete!');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
