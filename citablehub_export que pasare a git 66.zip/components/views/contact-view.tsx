"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Send, Loader2, CheckCircle, MessageSquare, HelpCircle, Bug, Lightbulb } from 'lucide-react';
import { toast } from 'sonner';

interface ContactViewProps {
  onNavigate: (path: string) => void;
}

const TOPICS = [
  { value: 'general', label: 'General Inquiry', icon: MessageSquare },
  { value: 'support', label: 'Technical Support', icon: HelpCircle },
  { value: 'bug', label: 'Bug Report', icon: Bug },
  { value: 'feature', label: 'Feature Request', icon: Lightbulb },
  { value: 'partnership', label: 'Partnership / Business', icon: Mail },
  { value: 'privacy', label: 'Privacy / Data Request', icon: Mail },
];

export default function ContactView({ onNavigate }: ContactViewProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [topic, setTopic] = useState('general');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error('Please fill in all required fields.');
      return;
    }
    setSending(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), email: email.trim(), topic, message: message.trim() }),
      });
      if (!res.ok) throw new Error('Failed');
      setSent(true);
      toast.success('Message sent! We\'ll get back to you soon.');
    } catch {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setSending(false);
    }
  };

  if (sent) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="py-20 text-center space-y-6 max-w-md mx-auto">
        <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto">
          <CheckCircle className="h-8 w-8 text-emerald-500" />
        </div>
        <h2 className="text-2xl font-extrabold font-display">Message Sent!</h2>
        <p className="text-muted-foreground text-sm">Thank you for reaching out. We typically respond within 24-48 hours.</p>
        <button
          onClick={() => onNavigate('/dashboard')}
          className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold text-sm cursor-pointer hover:bg-primary/90 transition"
        >
          Back to Dashboard
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="py-8 max-w-2xl mx-auto space-y-8">
      {/* Header */}
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Mail className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight font-display">Contact Us</h1>
            <p className="text-sm text-muted-foreground">We'd love to hear from you. Questions, feedback, partnership ideas — all welcome.</p>
          </div>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold">Name <span className="text-red-400">*</span></label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition"
              required
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold">Email <span className="text-red-400">*</span></label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition"
              required
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold">Topic</label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {TOPICS.map((t) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setTopic(t.value)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-medium border transition cursor-pointer ${
                    topic === t.value
                      ? 'bg-primary/10 border-primary/30 text-primary'
                      : 'bg-card border-border text-muted-foreground hover:border-primary/20'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {t.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold">Message <span className="text-red-400">*</span></label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Tell us what's on your mind..."
            rows={6}
            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition resize-none"
            required
          />
        </div>

        <button
          type="submit"
          disabled={sending}
          className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-bold text-sm cursor-pointer hover:bg-primary/90 transition disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {sending ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending...</> : <><Send className="h-4 w-4" /> Send Message</>}
        </button>
      </form>

      {/* Info */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-3">
        <h3 className="font-bold text-sm">Other ways to reach us</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-muted-foreground">
          <div>
            <p className="font-medium text-foreground">General</p>
            <p>hello@citablehub.com</p>
          </div>
          <div>
            <p className="font-medium text-foreground">Privacy & Legal</p>
            <p>privacy@citablehub.com</p>
          </div>
        </div>
      </div>

      {/* JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'ContactPage',
            name: 'Contact — CitableHub',
            description: 'Contact the CitableHub team for questions, support, partnerships, or privacy requests.',
            url: 'https://citablehub.com/contact',
            isPartOf: { '@type': 'WebSite', name: 'CitableHub', url: 'https://citablehub.com' },
          }),
        }}
      />
    </motion.div>
  );
}
