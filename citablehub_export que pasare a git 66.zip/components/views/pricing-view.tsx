"use client";

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Crown, Check, Sparkles, Zap, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useSession } from 'next-auth/react';

interface PricingViewProps {
  onNavigate: (path: string) => void;
}

const PLANS = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    desc: 'Get started with core discovery.',
    features: ['5 AI queries per day', 'Browse verified directory', 'Submit 1 project', 'Basic analytics'],
    cta: 'Current Plan',
    featured: false,
  },
  {
    id: 'plus',
    name: 'Plus',
    price: 29,
    desc: 'For active builders and seekers.',
    features: ['50 AI queries per day', 'Priority project review', 'Submit unlimited projects', 'Advanced analytics', 'BYO API key support'],
    cta: 'Upgrade to Plus',
    featured: true,
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 99,
    desc: 'Full-stack discovery and verification.',
    features: ['Unlimited AI queries', 'Same-day project review', 'Verified badge priority', 'Custom Schema.org config', 'Dedicated account manager', 'API access'],
    cta: 'Upgrade to Pro',
    featured: false,
  },
];

export default function PricingView({ onNavigate }: PricingViewProps) {
  const { data: session, update: updateSession } = useSession() || {};

  // Refresh session on mount to pick up plan changes from Stripe webhook
  useEffect(() => {
    updateSession?.();
  }, []);
  const [loading, setLoading] = useState<string | null>(null);

  const handleSelect = async (plan: any) => {
    if (plan.id === 'free') return;

    // Check authentication
    if (!session?.user) {
      toast.info('Inicia sesión para suscribirte');
      onNavigate('/auth/signin');
      return;
    }

    // Check if already on this plan
    if ((session?.user as any)?.subscription === plan.id) {
      toast.info(`Ya estás en el plan ${plan.name}`);
      return;
    }

    setLoading(plan.id);
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'subscription', planId: plan.id }),
      });
      const data = await res.json();
      if (data?.url) {
        window.location.href = data.url;
      } else {
        toast.error(data?.error || 'Error al crear la sesión de pago');
      }
    } catch (err) {
      toast.error('Error de conexión. Intenta nuevamente.');
    } finally {
      setLoading(null);
    }
  };

  const currentPlan = (session?.user as any)?.subscription || 'free';

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-10 py-8">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold bg-primary/10 text-primary border border-primary/20">
          <Crown className="h-3.5 w-3.5" />
          Transparent Pricing
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight font-display">Choose Your Plan</h1>
        <p className="text-muted-foreground">All plans include access to the verified software directory and Discovery AI.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {PLANS.map((plan: any, i: number) => {
          const isCurrentPlan = currentPlan === plan.id;
          const isLoading = loading === plan.id;

          return (
            <div
              key={i}
              className={`bg-card border rounded-xl p-6 space-y-5 transition ${
                plan?.featured ? 'border-primary shadow-lg ring-2 ring-primary/20 relative' : 'border-border hover:shadow-md'
              }`}
            >
              {plan?.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Popular
                </div>
              )}
              <div>
                <h3 className="text-lg font-bold font-display">{plan?.name}</h3>
                <p className="text-sm text-muted-foreground">{plan?.desc}</p>
              </div>
              <div className="text-4xl font-black font-display">
                ${plan?.price}<span className="text-sm font-normal text-muted-foreground">/mo</span>
              </div>
              <ul className="space-y-2">
                {(plan?.features ?? []).map((f: string, j: number) => (
                  <li key={j} className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => handleSelect(plan)}
                disabled={isCurrentPlan || isLoading}
                className={`w-full py-3 rounded-lg font-bold text-sm transition cursor-pointer flex items-center justify-center gap-2 ${
                  isCurrentPlan
                    ? 'bg-muted text-muted-foreground cursor-default'
                    : plan?.featured
                    ? 'bg-primary hover:bg-primary/90 text-primary-foreground'
                    : plan?.id === 'free'
                    ? 'bg-muted text-muted-foreground cursor-default'
                    : 'bg-card border border-border hover:shadow-md text-foreground'
                }`}
              >
                {isLoading ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Processing...</>
                ) : isCurrentPlan ? (
                  'Current Plan'
                ) : (
                  plan?.cta
                )}
              </button>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
